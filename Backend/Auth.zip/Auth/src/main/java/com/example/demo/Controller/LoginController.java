//package com.example.demo.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//import com.example.demo.Entity.User;
//
//import jakarta.servlet.http.HttpSession;
//
//@Controller
//@CrossOrigin
//@RequestMapping("/auth")
//public class LoginController {
//
//	@Autowired
//	UserService userservice; 
//
//	@PostMapping("/user/login")
//	public ResponseEntity<?> login(@RequestBody LoginDto login,HttpSession session){
//		User user = userservice.getUserByEmail(login.getEmail());
//		if (user != null) {
//			session.setAttribute("valid", true);
//			session.setAttribute("role", "user");
//			return new ResponseEntity<>(new UserDto(user),HttpStatus.OK);		
//			}
//		return null;
//	}
//	@PostMapping("/logout")
//	public ResponseEntity<?> logout(@RequestBody LoginDto login,HttpSession session){
//		session.invalidate();
//		return new ResponseEntity<>("logged out",HttpStatus.OK);
//	}
// 
//}
//
//
//

//  2
package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;

import org.springframework.http.*;

import javax.servlet.http.HttpSession;

@Controller
@CrossOrigin
@RequestMapping("/auth")
public class LoginController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/user/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest login, HttpSession session) {
        User user = userRepository.findByEmail(login.getEmail());
        if (user != null && login.getPassword().equals(user.getPassword())) {
            session.setAttribute("user", user);
            return new ResponseEntity<>(user, HttpStatus.OK);
        }
        return new ResponseEntity<>("Invalid credentials", HttpStatus.UNAUTHORIZED);
    }

    @PostMapping("/logout")
    public ResponseEntity<?> logout(HttpSession session) {
        session.invalidate();
        return new ResponseEntity<>("Logged out", HttpStatus.OK);
    }

    // Define a simple class for login request (can be in the same file or a separate one)
    static class LoginRequest {
        private String email;
        private String password;
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}

        // getters and setters
        // constructor

        // You can also use Lombok for generating getters, setters, and constructor
    }
}




