package com.example.demo.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.example.demo.Entity.User;
import com.example.demo.Repository.UserRepository;

@Controller
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    @GetMapping("/signup")
    public String showSignupForm(Model model) { 
        model.addAttribute("user", new User());
        return "signup";
    }
    
    // Hash the password before saving it to the database
    private String hashPassword(String password) {
        return BCrypt.hashpw(password, BCrypt.gensalt());
    }

    // Verify the password against its hashed version
    private boolean verifyPassword(String password, String hashedPassword) {
        return BCrypt.checkpw(password, hashedPassword);
    }
   @PostMapping("/signup")
    public String registerUser(@ModelAttribute("user") User user) {
        // You may want to add validation and error handling here
    	
    	String hashedPassword = hashPassword(user.getPassword());
        user.setPassword(hashedPassword);
    	userRepository.save(user);
        return "redirect:/login";
    	
    }
@PostMapping("/login")
    public String loginUser(@ModelAttribute("user") User user) {
        // You may want to add validation and error handling here
    	User existingUser = userRepository.findByEmail(user.getEmail());
        if (existingUser != null && verifyPassword(user.getPassword(), existingUser.getPassword())) {
            // Successful login, redirect to home page
            return "redirect:/home";
        } else {
            // Failed login, redirect back to login page
            return "redirect:/login";
        }
    }



    @GetMapping("/home")
    public String welcome() {
        return "home";
    }
    
    @GetMapping("/getme")
    public String getme() {
    	return "login";
    }
    
    
    @GetMapping("/getmee")
    public String getmee() {
        return "redirect:/home";
    }
    
    @GetMapping("/categories")
    public String categories() {
        return "categories";
    }
    @GetMapping("/start")
    public String start() {
        return "start";
    }
     
}




//SEssion?

//package com.example.demo.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCrypt;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import com.example.demo.Entity.User;
//import com.example.demo.Repository.UserRepository;
//
//import javax.servlet.http.HttpSession;
//
//@Controller
//public class AuthController {
//
//    @Autowired
//    private UserRepository userRepository;
//
//    @GetMapping("/login")
//    public String showLoginForm(HttpSession session) {
//        if (session.getAttribute("user") != null) {
//            // User is already logged in, redirect to home page
//            return "redirect:/home";
//        }
//        return "login";
//    }
//
//    @GetMapping("/signup")
//    public String showSignupForm(Model model, HttpSession session) {
//        if (session.getAttribute("user") != null) {
//            // User is already logged in, redirect to home page
//            return "redirect:/home";
//        }
//        model.addAttribute("user", new User());
//        return "signup";
//    }
//
//    // Hash the password before saving it to the database
//    private String hashPassword(String password) {
//        return BCrypt.hashpw(password, BCrypt.gensalt());
//    }
//
//    // Verify the password against its hashed version
//    private boolean verifyPassword(String password, String hashedPassword) {
//        return BCrypt.checkpw(password, hashedPassword);
//    }
//
//    @PostMapping("/signup")
//    public String registerUser(@ModelAttribute("user") User user, HttpSession session) {
//        // You may want to add validation and error handling here
//
//        String hashedPassword = hashPassword(user.getPassword());
//        user.setPassword(hashedPassword);
//        userRepository.save(user);
//
//        // Set the user in session after successful registration
//        session.setAttribute("user", user);
//        return "redirect:/home";
//    }
//
//    @PostMapping("/login")
//    public String loginUser(@ModelAttribute("user") User user, HttpSession session) {
//        // You may want to add validation and error handling here
//        User existingUser = userRepository.findByEmail(user.getEmail());
//        if (existingUser != null && verifyPassword(user.getPassword(), existingUser.getPassword())) {
//            // Successful login, set the user in session
//            session.setAttribute("user", existingUser);
//            return "redirect:/home";
//        } else {
//            // Failed login, redirect back to login page
//            return "redirect:/login";
//        }
//    }
//
//    @GetMapping("/home")
//    public String welcome(HttpSession session) {
//        // Check if the user is in session, otherwise redirect to login
//        if (session.getAttribute("user") == null) {
//            return "redirect:/login";
//        }
//        return "home";
//    }
//
//    @GetMapping("/getme")
//    public String getme(HttpSession session) {
//        // Check if the user is in session, otherwise redirect to login
//        if (session.getAttribute("user") == null) {
//            return "redirect:/login";
//        }
//        return "login";
//    }
//
//    @GetMapping("/getmee")
//    public String getmee(HttpSession session) {
//        // Check if the user is in session, otherwise redirect to login
//        if (session.getAttribute("user") == null) {
//            return "redirect:/login";
//        }
//        return "redirect:/home";
//    }
//
//    @GetMapping("/categories")
//    public String categories(HttpSession session) {
//        // Check if the user is in session, otherwise redirect to login
//        if (session.getAttribute("user") == null) {
//            return "redirect:/login";
//        }
//        return "categories";
//    }
//
//    @GetMapping("/start")
//    public String start(HttpSession session) {
//        // Check if the user is in session, otherwise redirect to login
//        if (session.getAttribute("user") == null) {
//            return "redirect:/login";
//        }
//        return "start";
//    }
//}
