package com.example.demo.Controller;

import com.example.demo.RepositoryService.OtpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/api/otp")
public class OtpController {

    @Autowired
    private OtpService otpService;

    
    
    @GetMapping("/generate")
    public String generateOtpForm() {
        return "generate"; // This will return generate-otp.html Thymeleaf template
    }
    @GetMapping("/validate")
    public String validateOtpForm() {
        return "validate-otp"; // This will return validate-otp.html Thymeleaf template
    }
    
    
    @PostMapping("/generate")
    public ResponseEntity<String> generateAndSendOtp(@RequestParam String email) {
        String generatedOtp = otpService.generateAndSendOtp(email);
        return ResponseEntity.ok("OTP generated successfully. Use this OTP for validation: " + generatedOtp);
    }

    @PostMapping("/validate")
    public ResponseEntity<String> validateOtp(@RequestParam String email, @RequestParam String enteredOtp) {
        boolean isValid = otpService.validateOtp(email, enteredOtp);

        if (isValid) {
            return ResponseEntity.ok("OTP is valid.");
        } else {
            return ResponseEntity.badRequest().body("Invalid OTP or expired.");
        }
    }
}


