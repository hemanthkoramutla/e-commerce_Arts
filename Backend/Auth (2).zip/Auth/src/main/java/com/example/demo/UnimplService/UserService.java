package com.example.demo.UnimplService;

public interface UserService {
    void updatePassword(String email, String newPassword);
    // other user-related methods...
}
