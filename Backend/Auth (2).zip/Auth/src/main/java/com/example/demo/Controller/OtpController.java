package com.example.demo.Controller;

import com.example.demo.Repository.UserRepository;
import com.example.demo.RepositoryService.OtpService;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api/otp")
public class OtpController {
	@Autowired
	UserRepository userRepository;
    @Autowired
    private OtpService otpService;

    
    
    @GetMapping("/generate")
    public String generateOtpForm() {
        return "generate"; // This will return generate-otp.html Thymeleaf template
    }
    @GetMapping("/validate")
    public String validateOtpForm() {
        return "validate-otp"; // This will return validate-otp.html Thymeleaf template
    }
    
    
//    @PostMapping("/generate")
//    public ResponseEntity<String> generateAndSendOtp(@RequestParam String email) {
//        String generatedOtp = otpService.generateAndSendOtp(email);
//        return ResponseEntity.ok("OTP generated successfully. Use this OTP for validation: " + generatedOtp);
//    }
    
//    @PostMapping("/generate")
//    public ResponseEntity<String> generateAndSendOtp(@RequestParam String email) {
//        // Check if the email exists in the customers' database
//        if (userRepository.existsByEmail(email)) {
//            // Email exists, generate and send OTP
//            String generatedOtp = otpService.generateAndSendOtp(email);
//            return ResponseEntity.ok("OTP generated successfully. Use this OTP for validation: " + generatedOtp);
//            
//        } else {
//            // Email doesn't exist, return an error response
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Please Signup First");
//        }
//    }

    
    @PostMapping("/generate")
    public String generateAndSendOtp(@RequestParam String email, Model model) {
        if (userRepository.existsByEmail(email)) {
            // Email exists, generate and send OTP
            String generatedOtp = otpService.generateAndSendOtp(email);
            model.addAttribute("generatedOtp", generatedOtp);
            return "validate-otp"; // Thymeleaf template name for the validation page
            
        } else {
            // Email doesn't exist, redirect to an error page
            return "errorPage"; // Thymeleaf template name for the error page
        }
    }
    
    
//    @PostMapping("/validate")
//    public ResponseEntity<String> validateOtp(@RequestParam String email, @RequestParam String enteredOtp) {
//        boolean isValid = otpService.validateOtp(email, enteredOtp);
//
//        if (isValid) {
//            return ResponseEntity.ok("OTP is valid.");
//        } else {
//            return ResponseEntity.badRequest().body("Invalid OTP or expired.");
//        }
//    }
    
    
    @PostMapping("/validate")
    public String validateOtp(@RequestParam String email, @RequestParam String enteredOtp) {
        boolean isValid = otpService.validateOtp(email, enteredOtp);

        if (isValid) {
        	return "reset-password";

        } else {
            return "index";
        }
    }
    @GetMapping("/reset-password")
    public String reset(Model model) { 
        return "reset-password";
    }
    


}


